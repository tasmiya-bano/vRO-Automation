# import requests
# import os
# import time

def handler(context, inputs):

    url = inputs.get("url")
    input_int = inputs.get("int_input")
    input_string = inputs.get("array_input")

    print("Performing get on url: ", url)
    # response = requests.get(url)
    # print("API status code is: ", response.status_code)
    # print("API response is: ", response.text)

    print("Testing input array now....")
    list_array(input_int)
    list_array(input_string)
    outputs = {
        "status": "done"
    }

    print("Testing Environment variable part...")
    # timer = os.getenv("SLEEP_TIME")
    # print("Sleeping for: ", timer)
    # time.sleep(int(timer))

    # print("Printing url from different module - %s" % TimerConstants.TMC_LOGIN_API)
    print("Run Complete !")

    return outputs


def list_array(elements_list):
    for input_el in elements_list:
        print("%s is of type %s" %(input_el, str(type(input_el))))