from enum import Enum

class TimerConstants:
    WAIT_TIME = 300
    SLEEP_TIME = 20
    TMC_LOGIN_API = (
        "https://console.cloud.vmware.com/csp/gateway/am/api/auth/api-tokens/authorize?refresh_token=refresh_token"
    )